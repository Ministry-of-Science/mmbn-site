Hey there and thanks for downloading the MMBN3D Demo! 

Mega Man Battle Network 3D - Demo Ver.
                            
               ,:::::::::.               
             :::,      `::::             
           :::             ::,           
          ::    ::::::::.   `::          
        `::   :::.     ,::,   ::         
        :.  :::          :::   ::        
       ::  ::            ::::`  ::       
      ::  ::             :::::   ::      
     .:  ,:              ::::::   :      
     :,  :`              :::::::  ::     
    `:  ::               :::::::   :     
    ::  :                ::::::::  :.    
    :` .:               `::::::::  ::    
    :  ::              `:,   ,:::   :    
    :  :`             .:.       :.  :    
   .:  :             ,:`        :,  :    
   .:  :            ,:`         ::  :    
   .:  :           ,:`          :,  :    
   `:  :          ::            :.  :    
    :  :,        ::             :   :    
    :  ,:       ::             `:  ,:    
    ::  :::::::::              ::  :,    
    `:  :::::::::              :   :     
     :.  ::::::::             ::  ::     
     .:  ::::::::            .:   :      
      ::  :::::::            :`  ::      
       :,  ::::::          .:,  ::       
        :`  :::::         ::`  ::        
        .:,  .:::       :::   ::         
          ::   ,:::::::::    ::          
           ::,     `.`     :::           
            `:::.       ,:::             
               ::::::::::,   

Development blog: mmbn3d.tumblr.com
Project twitter: http:/twitter.com/mmbn3d

=====================================

Click MMBN3D.exe to start the game in windowed mode! Click run.bat to start the game in borderless full screen mode! 

First off, the controls:
- Z = Accept (Chip usage)
- X = Decline (MegaBuster)
- Arrow keys = D-pad (Movement)
- A/S = L/R shoulder pads (Custom gauge)

The game does support gamepads but this has to be set in a menu that the demo does not have.

======================================

Email me at heatedphoenix@gmail.com if there's any problems and also if you find bugs. If possible send me either videos, screenshots or a detailed description of the bug in question. You can also e-mail me if you'd just like to tell me about how you feel about the project or suggestions or something of the sort.

======================================

This game has been in the works for almost 2 years. It has grown from being simply an idea two guys had to a fully playable 3D video game and I hope you'll enjoy playing it as much as I had creating it. 
I've put many hours of my life into this so it would not be an exaggeration to call this a passion project. I've got many more big plans in store for this project so stay tuned.
The next release after this demo will be an updated demo will bugfixes and such and after that the full release of the game.

Thanks again and hear from you guys soon,
Zacharia Karami 
(HeatPhoenix - http://twitter.com/heatphoenix)

---------------------------------------